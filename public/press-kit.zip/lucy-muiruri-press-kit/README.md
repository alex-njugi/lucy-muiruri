# Lucy Muiruri — Electronic Press Kit (EPK)

This folder contains a ready-to-send press kit for *Lucy Muiruri*, a Kenyan gospel artist.
It includes a short bio, extended bio, links to music/videos, a sample press release,
one-sheet, technical rider template, and brand assets folders.

> Tip: Keep this whole folder under 50–100 MB when zipped for easy emailing.
Update the files in place, then compress the **lucy-muiruri-press-kit** folder into a zip.

## Contents
- **01_Photos/** — Put 3–6 high-res images (JPG, 3000px+). Include at least one vertical and one horizontal.
- **02_Logos/** — SVG/PNG of logos or wordmark; include light/dark versions.
- **03_Bio/** — Short (50–80 words), Medium (120–180), Long (250–400) bios.
- **04_Music_Links/** — Streaming, download, and YouTube links.
- **05_Press_Release/** — Editable announcement template.
- **06_One_Sheet/** — Quick reference (one page) for promoters/editors.
- **07_Tech_Rider/** — Basic stage plot and input list template.
- **08_Contact/** — Booking & management contacts (VCF + TXT).
- **09_Social_Assets/** — Square/vertical promo templates or exported images.
- **10_Licensing/** — Photo credits & usage terms.

## Quick how-to
1. Drop your chosen images into **01_Photos/** and **09_Social_Assets/**.
2. Replace placeholders in the bios and press release with final dates/quotes.
3. Open **06_One_Sheet/ONE_SHEET.md** and update the highlights.
4. Export the one-sheet to PDF if needed.
5. Zip and upload — then link it on the website's “Download Press Kit” button.

Updated: 2025-10-06
