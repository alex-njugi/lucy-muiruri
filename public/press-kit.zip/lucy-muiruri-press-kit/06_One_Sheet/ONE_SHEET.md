# LUCY MUIRURI — ONE SHEET
**Genre:** Gospel / Worship (Kikuyu & English)  
**Location:** Kenya  
**Latest:** *Wi Munene* (2024)

## Highlights
- Uplifting worship with Kenyan roots
- Bilingual lyrics — Kikuyu & English
- Suitable for church events, conferences, concerts

## Notable Songs
- Murithi Mwega
- No Tugutoria
- Aira
- Ngai Mugaruri

## Quick Links
- YouTube: https://www.youtube.com/@lucymuiruri2115
- Spotify (single): https://open.spotify.com/track/7MpkiuQw0DwcwYitU5D2Do
- Apple Music (album): https://music.apple.com/us/album/wi-munene/1728263554

## Contact
**Bookings:** bookings@lucymuiruri.com | WhatsApp +254 718 183 789
