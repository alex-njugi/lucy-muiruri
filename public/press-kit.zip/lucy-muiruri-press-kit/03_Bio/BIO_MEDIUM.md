Lucy Muiruri is a Kenyan gospel artist known for a warm, uplifting sound that weaves Kikuyu and English worship.
Her music points listeners back to God with honest storytelling and memorable melodies. In 2024 she released **Wi Munene**,
a collection that includes fan favorites like “Murithi Mwega,” “No Tugutoria,” and “Ngai Mugaruri.”
Lucy performs at church events, concerts, and community gatherings, aiming to lift hearts and encourage faith.
