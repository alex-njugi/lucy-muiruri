Lucy Muiruri is a Kenyan gospel artist whose heartfelt worship blends Kikuyu and English lyrics.
Her 2024 release **Wi Munene** features songs like “Murithi Mwega” and “No Tugutoria,” carrying a message of hope and devotion.
