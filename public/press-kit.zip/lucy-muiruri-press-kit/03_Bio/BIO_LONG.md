**Lucy Muiruri** is a gospel artist from Kenya whose music blends contemporary worship with the rich textures of Kenyan
rhythms and language. Singing in both Kikuyu and English, Lucy writes songs that testify to God’s faithfulness and
speak to everyday life. Her 2024 project **Wi Munene** (“You Are Great”) highlights songs such as “Murithi Mwega”,
“No Tugutoria,” “Aira,” and “Ngai Mugaruri,” each carrying sing‑along choruses and messages of hope.
Lucy has ministered in churches, conferences, and community concerts, and is available for bookings locally and abroad.
