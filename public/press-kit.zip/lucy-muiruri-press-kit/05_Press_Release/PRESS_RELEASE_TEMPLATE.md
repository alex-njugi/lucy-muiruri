# PRESS RELEASE — For Immediate Release
**Artist:** Lucy Muiruri  
**Release Title:** Wi Munene (Album)  
**Date:** <Add Release Date>

**Short summary (2–3 sentences):**  
Kenyan gospel artist Lucy Muiruri announces *Wi Munene*, a worshipful collection
blending Kikuyu and English with contemporary gospel. The project includes “Murithi Mwega,”
“No Tugutoria,” and “Ngai Mugaruri,” pointing listeners to God's goodness.

## About the Release
(Add 1–2 paragraphs about the story behind the songs, production notes, notable collaborations, etc.)

## Key Tracks
- Murithi Mwega — (1–2 lines)
- No Tugutoria — (1–2 lines)
- Aira — (1–2 lines)
- Ngai Mugaruri — (1–2 lines)

## Streaming & Media
- YouTube: https://www.youtube.com/@lucymuiruri2115
- Spotify: https://open.spotify.com/track/7MpkiuQw0DwcwYitU5D2Do
- Apple Music: https://music.apple.com/us/album/wi-munene/1728263554

## Contact
**Bookings & Media:** bookings@lucymuiruri.com  
**WhatsApp:** +254 718 183 789  
**Instagram:** https://www.instagram.com/lucy.muiruri.906/

> Photos and logos included in the press kit may be used for editorial purposes with credit to the photographer where noted.
