# TECH RIDER — Lucy Muiruri (Template)

## 1) Performance Setup
- Vocals (Lucy): 1x wireless handheld mic
- BVs (optional): 1–2 mics
- Tracks/Playback (if used): Stereo DI (L/R) from laptop or device
- Keyboard (optional): 1x DI (L/R)
- Monitors: 2x wedges or in-ears (preferred if available)

## 2) Stage
- Minimum clear area 4m x 3m
- Sturdy mic stands, music stand (if needed)
- Power: 2x 13A outlets near stage

## 3) FOH / Mix Notes
- Natural vocal with light compression
- Reverb: small/medium plate or hall for worship
- Backing tracks at appropriate level for vocals to sit on top

## 4) Hospitality
- 2x still water (room temp)
- Green room access if available

This is a starting template; adjust to the specific event.
