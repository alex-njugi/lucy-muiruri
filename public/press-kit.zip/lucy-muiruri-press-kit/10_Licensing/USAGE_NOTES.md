# Asset Usage & Photo Credits
- Photos/logos supplied here are for editorial and promotional use related to Lucy Muiruri.
- Do not alter logos. Cropping/resizing photos is fine; do not add filters.
- Please include photographer credit where provided.
